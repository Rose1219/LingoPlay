# LingoPlay for iOS · 工程包说明

本压缩包为 LingoPlay 当前版本的 iOS 原生工程（Capacitor 8），已内置与网页版同步的前端产物（含最新页面与功能）及 TTS 语音插件源码，解压后可直接用 Xcode 打开构建，无需再执行 npm 构建。

- 版本：1.0.2（与 Android 端一致，重设计移动端界面排版，适配主流手机分辨率与刘海/挖孔屏安全区）
- Bundle ID：com.lingoplay.app
- 最低系统：iOS 15.0
- 后端地址：https://lingoplay.pocketbay.app/api（App 内直连）
- 发音能力：已集成 @capacitor-community/text-to-speech 原生插件（AVSpeechSynthesizer），包内 `node_modules/@capacitor-community/text-to-speech/` 为该插件源码（SPM 本地依赖，勿删）

## 构建 / 运行步骤

1. 环境要求：macOS 13+、Xcode 16+
2. 解压后进入 `ios/App`，打开 `App.xcodeproj`
3. Xcode 首次打开会自动拉取 SPM 依赖（capacitor-swift-pm 8.5.0，需联网；TTS 插件为包内本地依赖，无需下载）
4. Targets → App → Signing & Capabilities，选择你自己的 Apple 开发者证书（Bundle ID 默认 com.lingoplay.app，如冲突可改为自己的）
5. 连接 iPhone，选择设备后 Cmd+R 即可运行
6. 分发方式：Product → Archive 后导出 IPA（Ad Hoc / TestFlight / App Store）

## 常见问题

- **为什么不是 IPA？** iOS 应用必须使用 Apple 开发者证书签名后才能安装，未签名的 IPA 无法在任何设备上运行，因此官网分发可直接构建的工程包。
- **如何更新 App 内的网页内容？** 修改前端代码后执行 `npm install && npm run build && npx cap sync ios`，再重新 Archive。
- **如何切换后端地址？** 修改前端 `src/api/http.js` 中的 `NATIVE_API_BASE` 后重新构建。
